let gems = 1600;
const gameName = "Summoner";
let hasWon = false;

const Aeth = {
    name: "Aeth",
    health: 100,
    damage: 30,
    healing: 20,
    rarity: 5
};

const Luminere = {
    name: "Luminere",
    health: 80,
    damage: 15,
    healing: 0,
    rarity: 4
};

const Vodlytaine = {
    name: "Vodlytaine",
    health:  65,
    damage: 20,
    healing: 0,
    rarity: 4
};

const Flare = {
    name: "Flare",
    health: 30,
    damage: 15,
    healing: 0,
    rarity: 3
};

const Hydro = {
    name: "Hydro",
    health: 50,
    damage: 5,
    healing: 20,
    rarity: 3
};

const Daedra = {
    name: "Daedra",
    health: 40,
    damage: 10,
    healing: 10,
    rarity: 3
};

const pool = {
    5: [Aeth],
    4: [Luminere, Vodlytaine],
    3: [Flare, Hydro, Daedra],
    
};

function showInventory() {
    const inventoryDiv = document.getElementById("inventory");
    inventoryDiv.innerHTML = "";

    const sorted = inventory.slice().sort(function(a, b) {
        return b.rarity - a.rarity;
    });

    sorted.forEach(function(character) {
        const stars = "★".repeat(character.rarity);
        const btn = document.createElement("button");

        const inParty = party.includes(character);

        btn.textContent =
            character.name + " " + stars +
            " — HP:" + character.health +
            " DMG:" + character.damage +
            " HEAL:" + character.healing +
            (inParty ? " ✓ (in party)" : "");

        btn.style.display = "block"; 

        btn.addEventListener("click", function() {
            toggleParty(character);
        });

        inventoryDiv.appendChild(btn);
    });
}

function toggleParty(character) {
    const index = party.indexOf(character);

    if (index !== -1) {
        party.splice(index, 1);         
    } else if (party.length >= 3) {
        alert("Party is full (max 3). Remove someone first.");
        return;
    } else {
        party.push(character);           
    }

    showInventory(); 
    showParty();
}

function showParty() {
    const partyDiv = document.getElementById("party");
    partyDiv.innerHTML = "";

    if (party.length === 0) {
        partyDiv.textContent = "No characters equipped.";
        return;
    }

    party.forEach(function(character) {
        const stars = "★".repeat(character.rarity);
        const line = document.createElement("p");
        line.textContent = character.name + " " + stars +
            " — HP:" + character.health +
            " DMG:" + character.damage +
            " HEAL:" + character.healing;
        partyDiv.appendChild(line);
    });
}

function showBoss() {
    document.getElementById("bossInfo").textContent =
        boss.name + " — HP:" + boss.health + " DMG:" + boss.damage;
}

function fightBoss() {
    if (party.length === 0) {
        alert("You need at least one character in your party!");
        return;   
    }

    inBattle = true;
    bossCurrentHP = boss.health;
    battleParty = party.map(function(c) {
        return { ref: c, hp: c.health };
    });

    document.getElementById("menuScreen").style.display = "none";
    document.getElementById("battleScreen").style.display = "block";
    document.getElementById("healTargets").style.display = "none";

    drawBattle();
    setBattleMessage("A wild " + boss.name + " appears!");
    startPlayerTurn();   
}

function bossTurn() {
    const wantsToHeal = Math.random() < 0.3 && bossCurrentHP < boss.health;
    if (wantsToHeal) {
        bossCurrentHP += boss.healing;
        if (bossCurrentHP > boss.health) bossCurrentHP = boss.health;
        return boss.name + " heals for " + boss.healing + ".";
    }

    const living = battleParty.filter(function(member) {
        return member.hp > 0;
    });

    const targetIndex = Math.floor(Math.random() * living.length);
    const target = living[targetIndex];

    target.hp -= boss.damage;
    if (target.hp < 0) target.hp = 0;

    return boss.name + " attacks " + target.ref.name + " for " + boss.damage + " damage!";
    return boss.name + " attacks for " + boss.damage + " damage.";
}

function drawBattle() {
    document.getElementById("battleBoss").textContent =
        boss.name + " — HP: " + bossCurrentHP;

    const partyDiv = document.getElementById("battleParty");
    partyDiv.innerHTML = "";
    battleParty.forEach(function(member) {
        const line = document.createElement("p");
        const dead = member.hp <= 0 ? " (KO)" : "";
        line.textContent = member.ref.name + " — HP: " + member.hp + dead;
        partyDiv.appendChild(line);
    });
}

function partyTotalHP() {
    let total = 0;
    battleParty.forEach(function(member) {
        total += member.hp;
    });
    return total;
}

function startPlayerTurn() {
    if (!inBattle) return;
    selectedMember = null;

    document.getElementById("battleActions").style.display = "none";
    document.getElementById("healTargets").style.display = "none";

    const sel = document.getElementById("charSelect");
    sel.innerHTML = "Choose a character:  ";
    sel.style.display = "block";

    battleParty.forEach(function(member) {
        if (member.hp <= 0) return;
        const btn = document.createElement("button");
        btn.textContent = member.ref.name + " (HP:" + member.hp + ")";
        btn.addEventListener("click", function() {
            chooseCharacter(member);
        });
        sel.appendChild(btn);
    });
}

function chooseCharacter(member) {
    selectedMember = member;
    document.getElementById("charSelect").style.display = "none";
    document.getElementById("healTargets").style.display = "none";

    const actions = document.getElementById("battleActions");
    actions.style.display = "block";

    setBattleMessage("What should " + member.ref.name + " do?");
}

function playerAttack() {
    if (!inBattle || !selectedMember) return;

    const attacker = selectedMember;
    const dmg = attacker.ref.damage;
    bossCurrentHP -= dmg;

    let msg = attacker.ref.name + " hits " + boss.name + " for " + dmg + ".";

    if (bossCurrentHP <= 0) {
        bossCurrentHP = 0;
        drawBattle();
        winBattle();
        return;
    }

    msg += " " + bossTurn();
    drawBattle();

    if (partyTotalHP() <= 0) { loseBattle(); return; }

    setBattleMessage(msg);
    endPlayerTurn(); 
}

function setBattleMessage(text) {
    document.getElementById("battleMessage").textContent = text;
}

function showHealTargets() {
    if (!inBattle || !selectedMember) return;

    const healer = selectedMember;
    if (healer.ref.healing <= 0) {
        setBattleMessage(healer.ref.name + " has no healing power! Choose Attack.");
        return;
    }

    const targetsDiv = document.getElementById("healTargets");
    targetsDiv.innerHTML = "Heal who?  ";
    targetsDiv.style.display = "block";

    battleParty.forEach(function(member) {
        if (member.hp <= 0) return;
        const btn = document.createElement("button");
        btn.textContent = member.ref.name;
        btn.addEventListener("click", function() {
            healMember(member, healer.ref.healing);
        });
        targetsDiv.appendChild(btn);
    });
}

function healMember(target, amount) {
    target.hp += amount;
    if (target.hp > target.ref.health) target.hp = target.ref.health; 

    document.getElementById("healTargets").style.display = "none";

    let msg = target.ref.name + " is healed for " + amount + ".";
    msg += " " + bossTurn();
    drawBattle();

    if (partyTotalHP() <= 0) { loseBattle(); return; }

    setBattleMessage(msg);
    endPlayerTurn();
}

function endPlayerTurn() {
    if (!inBattle) return;
    startPlayerTurn();
}

function winBattle() {
    inBattle = false;
    document.getElementById("battleActions").style.display = "none";
    document.getElementById("charSelect").style.display = "none";
    document.getElementById("healTargets").style.display = "none";
    gems += 1600;
    hasWon = true;
    setBattleMessage("🎉 You defeated " + boss.name + "! +1600 gems. Returning to menu…");
    setTimeout(returnToMenu, 2500);
}

function loseBattle() {
    inBattle = false;
    document.getElementById("battleActions").style.display = "none";
    document.getElementById("charSelect").style.display = "none";
    document.getElementById("healTargets").style.display = "none";
    setBattleMessage("💀 Your party was defeated… Returning to menu…");
    setTimeout(returnToMenu, 2500);
}

function returnToMenu() {
    document.getElementById("battleScreen").style.display = "none";
    document.getElementById("menuScreen").style.display = "block";
    showParty();
    showBoss();
    showGems();
}

function endBattle(message) {
    const log = document.getElementById("battleLog");
    log.textContent = message;

    setTimeout(function() {
        alert(message + "\n\nReturning to menu...");
        party = [];       
        showParty();
        showBoss();
        document.getElementById("battleLog").textContent = "";
    }, 500);
}

function showGems() {
    document.getElementById("gemDisplay").textContent = "Gems: " + gems;
}

function rarityOdds() {
    const roll = Math.random();
    if (roll < 0.001) return 5;
    if (roll < 0.05) return 4;
    return 3;
}

function onewish(wish) {
    const rarity = rarityOdds();
    const list = pool[rarity];
    const character = list[Math.floor(Math.random() * list.length)];
    return character;
}

function tenwish(wish) {
    const results = [];
    for (let i = 0; i < 10; i++) {
        results.push(onewish());
    }
    return results; 
}

let party = [];
let inBattle = false;
let bossCurrentHP = 0;
let battleParty = [];   
let selectedMember = null; 

const boss = {
    name: "Kazuma the Reborn",
    health: 300,
    damage: 25,
    healing: 10
};

let inventory = [];

console.log("You have", gems, "gems");

const wishOneButton = document.getElementById("wishOne");
const wishTenButton = document.getElementById("wishTen");
const resultsDiv = document.getElementById("results");

wishOneButton.addEventListener("click", function() {
    if (gems < 160) { resultsDiv.textContent = "Not enough gems!"; return; }  
    gems -= 160; 
    let result = onewish();

    let alreadyOwned = inventory.some(function(character) {
        return character.name === result.name;
    });

    if (alreadyOwned) {
        resultsDiv.textContent = "Duplicate " + result.name + " - ignored.";
    } else {
        inventory.push(result);
        resultsDiv.textContent = "You got " + result.name + "!";
    }

    showInventory();
    showGems();
});

wishTenButton.addEventListener("click", function() {
    if (gems < 1600) { resultsDiv.textContent = "Not enough gems!"; return; } 
    gems -= 1600;

    let results = tenwish();
    let text = "";  

    for (let i = 0; i < results.length; i++) {
        let result = results[i];

        let alreadyOwned = inventory.some(function(character) {
            return character.name === result.name;
        });

        if (!alreadyOwned) {
            inventory.push(result);
            text = text + "You got " + result.name + "\n";
        } else {
            text = text + "Duplicate " + result.name + " - ignored.\n";
        }
    }

    resultsDiv.textContent = text;
    showInventory();
    showGems();
});

const challengeButton = document.getElementById("challengeBtn");
challengeButton.addEventListener("click", fightBoss);

showParty();
showBoss();

document.getElementById("freeGems").addEventListener("click", function() {
    gems += 1600;
    showGems();
});

document.getElementById("attackBtn").addEventListener("click", playerAttack);
document.getElementById("healBtn").addEventListener("click", showHealTargets);

console.log("Inventory has", inventory.length, "characters");