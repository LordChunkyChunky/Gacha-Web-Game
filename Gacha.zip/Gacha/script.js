const SINGLE_COST = 160;
const TEN_COUNT = 10;
const WIN_REWARD = 1600;
const FREE_GEMS = 1600;
const MAX_PARTY = 3;
const BOSS_HEAL_CHANCE = 0.3;
const MENU_RETURN_DELAY = 2500; 

const characters = [
    { name: "Aeth",       health: 100, damage: 30, healing: 20, rarity: 5 },
    { name: "Luminere",   health: 80,  damage: 15, healing: 0,  rarity: 4 },
    { name: "Vodlytaine", health: 65,  damage: 20, healing: 0,  rarity: 4 },
    { name: "Flare",      health: 30,  damage: 15, healing: 0,  rarity: 3 },
    { name: "Hydro",      health: 50,  damage: 5,  healing: 20, rarity: 3 },
    { name: "Daedra",     health: 40,  damage: 10, healing: 10, rarity: 3 }
];

function charactersOfRarity(rarity) {
    return characters.filter(function(c) {
        return c.rarity === rarity;
    });
}

const pool = {
    5: charactersOfRarity(5),
    4: charactersOfRarity(4),
    3: charactersOfRarity(3)
};

const boss = {
    name: "Kazuma the Reborn",
    health: 300,
    damage: 25,
    healing: 10
};

const state = {
    gems: 1600,
    inventory: [],
    party: [],
    inBattle: false,
    bossCurrentHP: 0,
    battleParty: [],      
    selectedMember: null
};

function setVisible(id, visible) {
    document.getElementById(id).classList.toggle("hidden", !visible);
}

function describeCharacter(c) {
    return c.name + " " + "★".repeat(c.rarity) +
        " — HP:" + c.health + " DMG:" + c.damage + " HEAL:" + c.healing;
}

function setMenuMessage(text) {
    document.getElementById("menuMessage").textContent = text;
}

function setBattleMessage(text) {
    document.getElementById("battleMessage").textContent = text;
}

function showGems() {
    document.getElementById("gemDisplay").textContent = "Gems: " + state.gems;
}

function showInventory() {
    const inventoryDiv = document.getElementById("inventory");
    inventoryDiv.innerHTML = "";

    if (state.inventory.length === 0) {
        inventoryDiv.textContent = "No characters yet. Summon to get your first one.";
        return;
    }

    const sorted = state.inventory.slice().sort(function(a, b) {
        return b.rarity - a.rarity;
    });

    sorted.forEach(function(character) {
        const inParty = state.party.includes(character);
        const btn = document.createElement("button");

        btn.className = "char-card rarity-" + character.rarity + (inParty ? " in-party" : "");
        btn.textContent = describeCharacter(character) + (inParty ? "  ✓ in party" : "");

        btn.addEventListener("click", function() {
            toggleParty(character);
        });

        inventoryDiv.appendChild(btn);
    });
}

function toggleParty(character) {
    const index = state.party.indexOf(character);

    if (index !== -1) {
        state.party.splice(index, 1);
    } else if (state.party.length >= MAX_PARTY) {
        setMenuMessage("Your party is full. Remove someone before adding " + character.name + ".");
        return;
    } else {
        state.party.push(character);
    }

    setMenuMessage("");
    showInventory();
    showParty();
}

function showParty() {
    const partyDiv = document.getElementById("party");
    partyDiv.innerHTML = "";

    if (state.party.length === 0) {
        partyDiv.textContent = "No characters equipped. Click one in your inventory to add them.";
        return;
    }

    state.party.forEach(function(character) {
        const line = document.createElement("p");
        line.className = "char-line rarity-" + character.rarity;
        line.textContent = describeCharacter(character);
        partyDiv.appendChild(line);
    });
}

function showBoss() {
    document.getElementById("bossInfo").textContent =
        boss.name + " — HP:" + boss.health + " DMG:" + boss.damage + " HEAL:" + boss.healing;
}

function rarityOdds() {
    const roll = Math.random();
    if (roll < 0.001) return 5;
    if (roll < 0.05) return 4;
    return 3;
}

function oneWish() {
    const list = pool[rarityOdds()];
    return list[Math.floor(Math.random() * list.length)];
}

function addToInventory(character) {
    const alreadyOwned = state.inventory.some(function(owned) {
        return owned.name === character.name;
    });

    if (alreadyOwned) {
        return "Duplicate " + character.name + " (ignored)";
    }

    state.inventory.push(character);
    return "You got " + character.name + " " + "★".repeat(character.rarity) + "!";
}

function summon(count) {
    const cost = count * SINGLE_COST;
    const resultsDiv = document.getElementById("results");

    if (state.gems < cost) {
        resultsDiv.textContent =
            "Not enough gems. This summon costs " + cost + " and you have " + state.gems + ".";
        return;
    }

    state.gems -= cost;

    const lines = [];
    for (let i = 0; i < count; i++) {
        lines.push(addToInventory(oneWish()));
    }

    resultsDiv.textContent = lines.join("\n");
    showInventory();
    showGems();
}

function fightBoss() {
    if (state.party.length === 0) {
        setMenuMessage("Add at least one character to your party before challenging the boss.");
        return;
    }

    setMenuMessage("");
    state.inBattle = true;
    state.bossCurrentHP = boss.health;
    state.battleParty = state.party.map(function(c) {
        return { ref: c, hp: c.health };
    });

    setVisible("menuScreen", false);
    setVisible("battleScreen", true);

    drawBattle();
    setBattleMessage("A wild " + boss.name + " appears!");
    startPlayerTurn();
}

function drawBattle() {
    document.getElementById("battleBoss").textContent =
        boss.name + " — HP: " + state.bossCurrentHP + " / " + boss.health;

    const partyDiv = document.getElementById("battleParty");
    partyDiv.innerHTML = "";

    state.battleParty.forEach(function(member) {
        const knockedOut = member.hp <= 0;
        const line = document.createElement("p");

        line.className = "char-line rarity-" + member.ref.rarity + (knockedOut ? " ko" : "");
        line.textContent = member.ref.name + " — HP: " + member.hp + " / " + member.ref.health +
            (knockedOut ? " (KO)" : "");

        partyDiv.appendChild(line);
    });
}

function partyTotalHP() {
    let total = 0;
    state.battleParty.forEach(function(member) {
        total += member.hp;
    });
    return total;
}

function startPlayerTurn() {
    if (!state.inBattle) return;
    state.selectedMember = null;

    setVisible("battleActions", false);
    setVisible("healTargets", false);

    const sel = document.getElementById("charSelect");
    sel.innerHTML = "<p>Choose a character:</p>";

    state.battleParty.forEach(function(member) {
        if (member.hp <= 0) return;

        const btn = document.createElement("button");
        btn.className = "btn-choice";
        btn.textContent = member.ref.name + " (HP: " + member.hp + ")";
        btn.addEventListener("click", function() {
            chooseCharacter(member);
        });
        sel.appendChild(btn);
    });

    setVisible("charSelect", true);
}

function chooseCharacter(member) {
    state.selectedMember = member;

    setVisible("charSelect", false);
    setVisible("healTargets", false);
    setVisible("battleActions", true);

    setBattleMessage("What should " + member.ref.name + " do?");
}

function playerAttack() {
    if (!state.inBattle || !state.selectedMember) return;

    const attacker = state.selectedMember;
    const dmg = attacker.ref.damage;
    state.bossCurrentHP -= dmg;

    let msg = attacker.ref.name + " hits " + boss.name + " for " + dmg + ".";

    if (state.bossCurrentHP <= 0) {
        state.bossCurrentHP = 0;
        drawBattle();
        winBattle();
        return;
    }

    msg += " " + bossTurn();
    drawBattle();

    if (partyTotalHP() <= 0) {
        loseBattle();
        return;
    }

    setBattleMessage(msg);
    startPlayerTurn();
}

function showHealTargets() {
    if (!state.inBattle || !state.selectedMember) return;

    const healer = state.selectedMember;
    if (healer.ref.healing <= 0) {
        setBattleMessage(healer.ref.name + " can't heal. Choose Attack instead.");
        return;
    }

    const targetsDiv = document.getElementById("healTargets");
    targetsDiv.innerHTML = "<p>Heal who?</p>";

    state.battleParty.forEach(function(member) {
        if (member.hp <= 0) return;

        const btn = document.createElement("button");
        btn.className = "btn-choice";
        btn.textContent = member.ref.name + " (HP: " + member.hp + ")";
        btn.addEventListener("click", function() {
            healMember(member, healer.ref.healing);
        });
        targetsDiv.appendChild(btn);
    });

    setVisible("healTargets", true);
}

function healMember(target, amount) {
    target.hp += amount;
    if (target.hp > target.ref.health) target.hp = target.ref.health;

    setVisible("healTargets", false);

    let msg = target.ref.name + " is healed for " + amount + ".";
    msg += " " + bossTurn();
    drawBattle();

    if (partyTotalHP() <= 0) {
        loseBattle();
        return;
    }

    setBattleMessage(msg);
    startPlayerTurn();
}

function bossTurn() {
    const wantsToHeal = Math.random() < BOSS_HEAL_CHANCE && state.bossCurrentHP < boss.health;

    if (wantsToHeal) {
        state.bossCurrentHP += boss.healing;
        if (state.bossCurrentHP > boss.health) state.bossCurrentHP = boss.health;
        return boss.name + " heals for " + boss.healing + ".";
    }

    const living = state.battleParty.filter(function(member) {
        return member.hp > 0;
    });

    const target = living[Math.floor(Math.random() * living.length)];
    target.hp -= boss.damage;
    if (target.hp < 0) target.hp = 0;

    return boss.name + " attacks " + target.ref.name + " for " + boss.damage + " damage!";
}

function stopBattle() {
    state.inBattle = false;
    setVisible("battleActions", false);
    setVisible("charSelect", false);
    setVisible("healTargets", false);
    setTimeout(returnToMenu, MENU_RETURN_DELAY);
}

function winBattle() {
    state.gems += WIN_REWARD;
    setBattleMessage("You defeated " + boss.name + "! +" + WIN_REWARD + " gems. Returning to menu…");
    stopBattle();
}

function loseBattle() {
    setBattleMessage("Your party was defeated. Returning to menu…");
    stopBattle();
}

function returnToMenu() {
    setVisible("battleScreen", false);
    setVisible("menuScreen", true);
    showGems();
    showInventory();
    showParty();
    showBoss();
}

const wishOneButton = document.getElementById("wishOne");
const wishTenButton = document.getElementById("wishTen");

wishOneButton.textContent = "Summon ×1 (" + SINGLE_COST + " gems)";
wishTenButton.textContent = "Summon ×" + TEN_COUNT + " (" + (SINGLE_COST * TEN_COUNT) + " gems)";

wishOneButton.addEventListener("click", function() {
    summon(1);
});

wishTenButton.addEventListener("click", function() {
    summon(TEN_COUNT);
});

document.getElementById("freeGems").addEventListener("click", function() {
    state.gems += FREE_GEMS;
    showGems();
});

document.getElementById("challengeBtn").addEventListener("click", fightBoss);
document.getElementById("attackBtn").addEventListener("click", playerAttack);
document.getElementById("healBtn").addEventListener("click", showHealTargets);

showGems();
showInventory();
showParty();
showBoss();