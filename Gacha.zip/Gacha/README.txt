# Summoner

A browser-based gacha game built with vanilla JavaScript, HTML, and CSS. Summon
characters using a probability-based reward system, build a party, and fight a
boss in turn-based combat.

This was built as a self-directed project to practise core web development
concepts without relying on a framework.

## Features

- **Gacha summoning**: spend gems to summon characters via a weighted random
  system with three rarity tiers (3★, 4★, 5★), with single and 10× pulls.
- **Gem economy**: summons cost gems, wins reward gems, and pulls are blocked
  when you can't afford them.
- **Inventory**: owned characters are listed with their stats and star rating,
  sorted by rarity and colour-coded by tier.
- **Party system**: equip up to three characters for battle.
- **Turn-based combat**: choose one character each turn to attack or heal, with
  each character using their own health, damage, and healing stats. The boss
  responds each turn by attacking a random party member or healing itself.
- **Win/lose flow**: battle outcomes are shown on screen before returning to
  the menu.

## How to play

1. Use the summon buttons to pull characters (or the "+1600 gems" testing
   button to top up).
2. Click characters in your inventory to add them to your party (max 3).
3. Press **Challenge boss** to start a fight.
4. Each turn, pick a character, then choose **Attack** or **Heal**.
5. Defeat the boss to earn gems, or return to the menu if your party falls.

## Running it locally

No build tools or dependencies required.

1. Clone or download this repository.
2. Open `index.html` in your web browser.

## Built with

- HTML
- CSS
- JavaScript (no libraries or frameworks)

## Project structure

- `index.html`: page layout for the menu and battle screens
- `style.css`: styling, including rarity colours
- `script.js`: game data, game state, and all game logic

## What I learned

- Manipulating the DOM directly to render game state (inventory, party, battle).
- Managing state that persists between user actions to drive a turn-based loop.
- Implementing a weighted random system for the summon rarities.
- Separating game data from display logic (e.g. keeping live battle HP separate
  from characters' base stats, and sorting a copy of the inventory for display).
- Debugging with browser developer tools.

## Possible improvements

- Save progress between visits using `localStorage`.
- Convert duplicate characters into gems or use them to level characters up.
- Add a pity system that guarantees a 5★ after a set number of summons.
- Add more bosses with increasing difficulty.
- Add animations for summons and attacks.
- Move the summoning logic to a server so results can't be manipulated in the
  browser.

## Author

Syed Ali Hamza Gilani